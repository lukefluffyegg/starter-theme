<?php
	
	/*=================================================
	=            Enqueue Assets | CSS & JS            =
	=================================================*/

	function enqueue_assets ()
	{	
		wp_enqueue_style('master', get_template_directory_uri() . '/css/master.css');

		wp_deregister_script('jquery');
		wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-1.11.1.min.js', array(), '1.11.1', true);

		wp_register_script('controller', get_template_directory_uri() . '/js/controller.min.js', array(), '1.0.0', true);
		wp_localize_script('controller', 'wp_config', array('site_url' => site_url()));
		wp_enqueue_script('controller');
	}

	add_action('wp_enqueue_scripts', 'enqueue_assets');

	/*=============================================
	=            Adds Media Uploader Assets       =
	=============================================*/

	function load_wp_media_files() 
	{
		wp_enqueue_media();
	}

	add_action('admin_enqueue_scripts', 'load_wp_media_files');

	/*=====================================================
	=            Register thumbnails for posts            =
	=====================================================*/

	if (function_exists('add_theme_support'))
	{
		add_theme_support('post-thumbnails') ;  
	}

	/*========================================================================================
	=            Adds image sizes | add_image_size(slug, width, height, hardcrop)            =
	=========================================================================================*/

	// if (function_exists('add_image_size'))
	// { 
	// 	add_image_size('header-image', 1600, 460, true);
	// }
	
	/*=============================================================================
	=            Register Navigations | register_nav_menu(slug, title)            =
	==============================================================================*/

	//register_nav_menu('header-navigation', 'Header Navigation');

	/*===========================================================
	=            Returns link add the end of excerpt            =
	============================================================*/
	
	function new_excerpt_more ($more) 
	{
		return '... <a class="read-more" href="'. get_permalink( get_the_ID() ) . '">' . __('read more', 'tms') . '</a>';
	}

	add_filter( 'excerpt_more', 'new_excerpt_more' );

	/*====================================================
	=            Changes excerpts word length            =
	====================================================*/

	function custom_excerpt_length ($length) 
	{
		return 40;
	}

	add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );	
?>