<?php
/**
*
* Footer
*
**/
?>	
	<footer id="main-footer">
		<div class="container">
			<h1>Footer</h1>
			<p class="text-right">&copy; <?=date('Y');?> {website} | website by <a href="http://tms-media.co.uk" target="_blank">TMS Media</a></p>
		</div>
	</footer>

	<?php wp_footer(); ?>
    
</body>
</html>

