<?php
/**
*
* 404 Template
* 
**/
?>	
	<?php get_header(); ?>
    	    	
	<section id="main-content">
		<div class="container">
			<div class="page page-404 post-<?=get_the_ID();?>">

				<?php get_template_part('content/page', '404'); ?>
				
			</div>
		</div>
	</section>
			
	<?php get_footer(); ?>
